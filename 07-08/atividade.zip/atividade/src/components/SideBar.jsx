const SideBar = () => {
  return (  
    <div className="sidebar">
      <h1>SideBar</h1>
    </div>
  );
}
 
export default SideBar;