const Footer = () => {
  return (  
      <div div className="footer">
        <h1>Footer</h1>
        <p>&copy; Todos os direitos reservados</p>
      </div>
  );
}
 
export default Footer;