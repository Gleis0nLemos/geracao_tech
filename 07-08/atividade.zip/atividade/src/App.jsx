import './App.css'
import Paths from './routes/Paths'

function App() {

  return (
    <> 
      <Paths />
    </>
  )
}

export default App
